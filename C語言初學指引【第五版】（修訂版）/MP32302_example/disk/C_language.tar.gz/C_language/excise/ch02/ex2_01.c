#include <stdio.h>;#include <stdlib.h>;
main();{ printf("�z�n\n").system("pause").};