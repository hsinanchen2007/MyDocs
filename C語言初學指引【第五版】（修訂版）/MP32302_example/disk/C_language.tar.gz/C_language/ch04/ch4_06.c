/*    �ɦW:ch4_06.c    �\��:[width][.prec]�Ѽ�     */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 float data1=123.4;
 float data2 = 45.678;
 float data3 = 0.92;
  
 printf("data1==>%09.5f\n",data1);
 printf("data2==>%09.5f\n",data2);
 printf("data3==>%09.5f\n",data3);
 /*  system("pause");  */
}
