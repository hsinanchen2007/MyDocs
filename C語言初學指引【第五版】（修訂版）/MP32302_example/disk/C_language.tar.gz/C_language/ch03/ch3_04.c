/***************************
    �ɦW:ch3_04.c
    �\��:����B��l
 ***************************/

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int x=10,y=20;
 
 printf(" x=%d",x);
 printf(" y=%d\n",y);
 printf("1�N���u,0�N����\n");
 printf("x==y ==> %d\n",(x==y));
 printf("x!=y ==> %d\n",(x!=y));
 printf("x>y  ==> %d\n",(x>y));
 printf("x<y  ==> %d\n",(x<y));
 printf("x>=y ==> %d\n",(x>=y));
 printf("x<=y ==> %d\n",(x<=y));
 system("pause");
}
