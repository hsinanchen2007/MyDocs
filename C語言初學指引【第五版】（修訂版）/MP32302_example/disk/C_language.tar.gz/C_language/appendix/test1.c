#include <stdio.h>

int main(void)
{
 int i;
 for(i=1;i<5;i++)
 {
   a=a+i;
   printf("a=%d\n",a);
 }
}
