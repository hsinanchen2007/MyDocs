/*****************************
    �ɦW:pro1.c
    �\��:����
 *****************************/

#define Sum(a,b) (a)+(b)
#define Mul(a,b) (a)*(b)

void main(void)
{
 int a=1,b=2,c=3,d=4;
 int result1,result2;
 
 result1=Sum(a*b,c*d);
 result2=Mul(a+b,c+d);
}
