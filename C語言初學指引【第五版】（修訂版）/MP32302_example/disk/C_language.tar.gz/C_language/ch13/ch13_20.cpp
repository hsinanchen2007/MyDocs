/*    �ɦW:ch13_20.cpp    �\��:this����   */

#include <stdlib.h>
#include <stdio.h>

class myclass
{
  public:
     void SetVarA(int);
     void SetVarB(int);
     void ShowData();
  private:
     int VarA;
     int VarB;
};

void myclass::SetVarA(int value)
{
    this->VarA=value;
}
void myclass::SetVarB(int value)
{
    this->VarB=value;
}
void myclass::ShowData()
{
    printf("VarA=%d\n",this->VarA);
    printf("VarB=%d\n",this->VarB);
}

int main(void)
{
   myclass ObjX;

   ObjX.SetVarA(100);
   ObjX.SetVarB(200);
   ObjX.ShowData();
   /* system("pause"); */
   return 0;
}
