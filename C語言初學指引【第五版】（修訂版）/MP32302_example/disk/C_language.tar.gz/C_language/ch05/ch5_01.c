/*    �ɦW:ch5_01.c    �\��:�`�ǵ��c     */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int x;
 x
 =
 1
 ;
 printf("%d\n",x);
 x=x+1;
 printf("%d\n",x);
 /*  system("pause");  */
}
