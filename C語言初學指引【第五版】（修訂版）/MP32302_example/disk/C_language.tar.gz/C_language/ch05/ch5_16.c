/*    �ɦW:ch5_16.c    �\��:�h�hfor�j�骺�ܽd   */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int i,j;
 for(i=1;i<=9;i++)
 {
    for(j=1;j<=9;j++)
       printf("%d*%d=%d\t",i,j,i*j);
    printf("\n");
 }
 /*  system("pause");  */
}
