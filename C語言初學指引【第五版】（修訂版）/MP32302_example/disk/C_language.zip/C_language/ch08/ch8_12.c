/*    �ɦW:ch8_12.c    �\��:���а}�C�P�r��}�C    */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int i;
 char *Week[7]= \
 {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
     
 for(i=0;i<=6;i++)
    printf("Week[%d]=%s\n",i,Week[i]);
 /*  system("pause");  */
}
