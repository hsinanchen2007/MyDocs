/*****************************
    �ɦW:pro2.c
    �\��:warning
 *****************************/

int main(void)
{
 float a=1,b=2,c=3,d=4;
 int result1,result2;
 
 result1=a*b+c*d;
 result2=(a+b)*(c+d);
}
