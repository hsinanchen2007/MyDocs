/*    �ɦW:ch4_08.c    �\��:[F|N|h|l|L]�Ѽ�    */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int var1=0x281a820e;

 printf("var1==>%#8x\n",var1);
 printf("var1==>%#8hx\n",var1);
 /*  system("pause");  */
}
