/*    �ɦW:ch4_15.c    �\��:puts�禡    */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 char *str1="Hello!";
 char *str2="Welcome!";

 puts(str1);
 puts(str2);
 /*  system("pause");  */
}
