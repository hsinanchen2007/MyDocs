/*    �ɦW:ch4_09.c    �\��:����r��    */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 printf("12345678901234567890\n");
 printf("Hello\n");
 printf("\tHello\n");
 printf("\t\tHello\n");
 printf("\t\rHello\n");
 /*  system("pause");  */
}
