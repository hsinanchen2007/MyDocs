/*    �ɦW:ch3_09.c    �\��:�۰ʫ��A�ഫ     */

#include <stdio.h>
#include <stdlib.h>

void main(void)
{
 int a=8,b;
 double c=3.1416;
 b=a+c;

 printf("b = %d\n",b);
 system("pause");
}
