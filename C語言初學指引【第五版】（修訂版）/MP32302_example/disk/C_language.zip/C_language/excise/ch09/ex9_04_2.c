int Sum;
const int qty=5;
float Avg;

void Compute_Avg(void)
{
 Avg=Sum/qty;
}