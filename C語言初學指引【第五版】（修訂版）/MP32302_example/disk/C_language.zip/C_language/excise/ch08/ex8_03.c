#include <stdlib.h>

void main(void)
{
 char *str1="My dear friend";
 char *str2=DeleteEmpty(str1);

 printf("str1��:%s\n",str1);
 printf("str2��:%s\n",str2);
}