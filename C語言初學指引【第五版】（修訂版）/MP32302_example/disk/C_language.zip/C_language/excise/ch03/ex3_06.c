/* ex3_06.c  ASCII�X���m��   */
#include <stdio.h>
#include <stdlib.h>
void main(void)
{
 char a=98,b=101,c=107;
 
 printf("%c\n",a);
 printf("%c\n",b);
 printf("%c\n",b);
 printf("%c\n",c);
 system("pause");
}
